package com.eif.data;

public class User {

	public void add(User us) {
		
	}
	public void saveUser(User us) {
		
	}
	public User orElse(Object object) {
		// TODO Auto-generated method stub
		return null;
	}

}
